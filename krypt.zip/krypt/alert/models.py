from django.db import models

# Create your models here.
from django.db import models


class alert(models.Model):
    alert_price = models.CharField(max_length=100)
