import json
import smtplib
from django.shortcuts import render
from django.http import HttpResponse
from alert.models import alert
import requests
from email.message import EmailMessage


# Create your views here.
def create(request):
    if request.method == 'GET':
        return render(request, "create.html")
    else:
        alert_at = str(request.POST['alert_number'])
        ins = alert(alert_price=alert_at)
        ins.save()
        alert_check(request)
        return render(request, "create.html", {'msg': "Alert has been created"})


def delete(request):
    alert_object = alert.objects.all()
    alert_object.delete()
    return HttpResponse("Alerts have been deleted")


def fetch(request):
    alert_object = alert.objects.all()
    print("Alert object: ", alert_object)
    # context = {'success': "True"}
    alert_check(request)
    return render(request, "fetch.html", {'alert_object': alert_object})


def email(price):
    #Mailtrap has been used for testing the email
    server = smtplib.SMTP("smtp.mailtrap.io", 2525)
    server.login("733a5f36897522", "d2778a9b8ce49e")
    msg = EmailMessage()
    msg['From'] = "notification.alert@gmail.com"
    SUBJECT = "Alert!"
    msg['Subject'] = SUBJECT
    msg['To'] = 'varunmanagari987@gmail.com'
    content="Alert has been hit at "+price
    msg.set_content(content)
    server.send_message(msg)
    server.quit()


def alert_check(request):
    for a in alert.objects.all():
        api_crypto = requests.get(
            "https://api.coingecko.com/api/v3/coins/markets?vs_currency=USD&order=market_cap_desc&per_page=100&page=1"
            "&sparkline=false")
        data = api_crypto.text
        data_json = json.loads(data)
        active_case = data_json[0]['current_price']
        print("Active price: ", active_case)
        if int(a.alert_price) == active_case:
            print("Your alert has been hit!")
            email(a.alert_price)
            break
